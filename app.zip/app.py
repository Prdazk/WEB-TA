import cv2
import pandas as pd
from ultralytics import YOLO
from threading import Thread
import os
from dotenv import load_dotenv
import cvzone
import numpy as np

load_dotenv()
db_path = os.getenv('MODELS_PATH')

class VideoCaptureAsync:
    def __init__(self, src):
        self.cap = cv2.VideoCapture(src)
        self.ret, self.frame = self.cap.read()
        self.running = True

    def start(self):
        Thread(target=self.update, daemon=True).start()
        return self

    def update(self):
        while self.running:
            self.ret, self.frame = self.cap.read()

    def read(self):
        return self.ret, self.frame

    def stop(self):
        self.running = False
        self.cap.release()

def iou(boxA, boxB):
    xA = max(boxA[0], boxB[0])
    yA = max(boxA[1], boxB[1])
    xB = min(boxA[2], boxB[2])
    yB = min(boxA[3], boxB[3])
    interArea = max(0, xB-xA) * max(0, yB-yA)
    boxAArea = (boxA[2]-boxA[0]) * (boxA[3]-boxA[1])
    boxBArea = (boxB[2]-boxB[0]) * (boxB[3]-boxB[1])
    return interArea / (boxAArea + boxBArea - interArea + 1e-6)

# Load YOLO model tanpa device (gunakan device saat predict)
model = YOLO(db_path)

# Load class list dari coco.txt
with open("./coco.txt", "r") as f:
    class_list = f.read().strip().split("\n")

video_url = "http://localhost:3000/hls/output.m3u8"
cap = VideoCaptureAsync(video_url).start()

small_width, small_height = 720, 360
frame_skip = 3  # skip frame untuk percepatan

count = 0
scale_box = 0.85  # skala bounding box 85% dari ukuran asli

while True:
    ret, frame = cap.read()
    if not ret or frame is None:
        continue

    count += 1
    if count % frame_skip != 0:
        continue

    frame_small = cv2.resize(frame, (small_width, small_height))
    results = model(frame_small, verbose=False, device="CPU")

    motors = []
    helmets = []

    # Proses deteksi
    for r in results:
        boxes_data = pd.DataFrame(r.boxes.data).astype(float)
        for index, row in boxes_data.iterrows():
            x1, y1, x2, y2 = map(int, row[:4])
            conf = float(row[4])
            cls = int(row[5])
            label_name = class_list[cls]  # helmet / no_helmet

            # Simpan koordinat sesuai label
            if label_name == "helmet":
                helmets.append((x1, y1, x2, y2))
            else:
                motors.append((x1, y1, x2, y2))

            # Sesuaikan ukuran bounding box agar lebih kecil
            w = x2 - x1
            h = y2 - y1
            x1_adj = int(x1 + (1-scale_box)/2 * w)
            y1_adj = int(y1 + (1-scale_box)/2 * h)
            x2_adj = int(x2 - (1-scale_box)/2 * w)
            y2_adj = int(y2 - (1-scale_box)/2 * h)

            color = (0,255,0) if label_name == "helmet" else (0,0,255)
            cv2.rectangle(frame_small, (x1_adj, y1_adj), (x2_adj, y2_adj), color, 2)
            cvzone.putTextRect(frame_small, f'{label_name} {conf:.2f}', (x1_adj, y1_adj), scale=1, thickness=1, colorR=color)

    # Cek motor dengan helm / no helm
    for mx1,my1,mx2,my2 in motors:
        has_helmet = False
        for hx1,hy1,hx2,hy2 in helmets:
            if iou((mx1,my1,mx2,my2),(hx1,hy1,hx2,hy2)) > 0.10:
                has_helmet = True
                break

        # Sesuaikan bounding box motor juga
        w = mx2 - mx1
        h = my2 - my1
        mx1_adj = int(mx1 + (1-scale_box)/2 * w)
        my1_adj = int(my1 + (1-scale_box)/2 * h)
        mx2_adj = int(mx2 - (1-scale_box)/2 * w)
        my2_adj = int(my2 - (1-scale_box)/2 * h)

        color = (0,255,0) if has_helmet else (0,0,255)
        label_text = "Helmet" if has_helmet else "No Helmet"
        cv2.rectangle(frame_small, (mx1_adj, my1_adj), (mx2_adj, my2_adj), color, 2)
        cv2.putText(frame_small, label_text, (mx1_adj, my1_adj-5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1)

    cv2.imshow("Helmet Detection", frame_small)
    if cv2.waitKey(1) & 0xFF == 27:
        break

cap.stop()
cv2.destroyAllWindows()